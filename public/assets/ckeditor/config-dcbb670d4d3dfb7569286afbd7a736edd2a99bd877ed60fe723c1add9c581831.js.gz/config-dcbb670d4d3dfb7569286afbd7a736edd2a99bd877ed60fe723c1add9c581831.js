// テキストエリアの幅
CKEDITOR.config.width  = '100%';
// テキストエリアの高さ
CKEDITOR.config.height = '400px';
